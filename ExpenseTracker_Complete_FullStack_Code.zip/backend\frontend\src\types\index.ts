export type TransactionType = 'INCOME' | 'EXPENSE';

export type Category =
  | 'Food'
  | 'Transport'
  | 'Education'
  | 'Shopping'
  | 'Entertainment'
  | 'Salary'
  | 'Allowance'
  | 'Other';

export interface Transaction {
  id: number;
  type: TransactionType;
  amount: number;
  category: string;
  description?: string;
  transactionDate: string; // YYYY-MM-DD
  createdAt: string;
}

export interface TransactionRequest {
  type: TransactionType;
  amount: number;
  category: string;
  description?: string;
  transactionDate: string;
}

export interface CategoryExpense {
  category: string;
  amount: number;
  percentage: number;
}

export interface DashboardSummary {
  totalIncome: number;
  totalExpenses: number;
  availableBalance: number;
  totalTransactionCount: number;
  categoryExpenses: CategoryExpense[];
  recentTransactions: Transaction[];
}

export interface MonthlyReport {
  month: number;
  year: number;
  monthlyIncome: number;
  monthlyExpenses: number;
  monthlyBalance: number;
  categoryExpenses: CategoryExpense[];
  highestSpendingCategory: string | null;
  highestSpendingAmount: number;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: Date;
  intent?: string;
}
