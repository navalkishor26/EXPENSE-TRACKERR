import React, { useEffect, useState } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  Receipt,
  ArrowRight,
  AlertCircle,
  PlusCircle,
  Clock,
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from 'recharts';
import { api } from '../api/client';
import { DashboardSummary } from '../types';
import { formatINR, formatDate } from '../utils/formatters';

interface DashboardViewProps {
  onNavigateToAdd: () => void;
  onNavigateToHistory: () => void;
}

const CATEGORY_COLORS: Record<string, string> = {
  Food: '#ef4444',
  Transport: '#f97316',
  Education: '#8b5cf6',
  Shopping: '#ec4899',
  Entertainment: '#eab308',
  Salary: '#10b981',
  Allowance: '#06b6d4',
  Other: '#64748b',
};

const DEFAULT_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899'];

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigateToAdd,
  onNavigateToHistory,
}) => {
  const [data, setData] = useState<DashboardSummary | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      setError(null);
      const summary = await api.getDashboardSummary();
      setData(summary);
    } catch (err: unknown) {
      if (err instanceof Error) {
        setError(err.message || 'Failed to load dashboard data');
      } else {
        setError('Failed to load dashboard data');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-sm text-slate-500 font-medium">Loading dashboard summary from database...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-rose-50 border border-rose-200 rounded-2xl p-6 text-center max-w-lg mx-auto my-8">
        <AlertCircle className="w-10 h-10 text-rose-500 mx-auto mb-3" />
        <h3 className="text-base font-semibold text-rose-800">Connection Error</h3>
        <p className="text-sm text-rose-600 mt-1 mb-4">{error}</p>
        <button
          onClick={fetchDashboard}
          className="px-4 py-2 bg-rose-600 text-white rounded-xl text-sm font-medium hover:bg-rose-700 transition-colors"
        >
          Retry Connection
        </button>
      </div>
    );
  }

  const {
    totalIncome = 0,
    totalExpenses = 0,
    availableBalance = 0,
    totalTransactionCount = 0,
    categoryExpenses = [],
    recentTransactions = [],
  } = data || {};

  const pieData = categoryExpenses.map((cat, idx) => ({
    name: cat.category,
    value: Number(cat.amount),
    percentage: cat.percentage,
    color: CATEGORY_COLORS[cat.category] || DEFAULT_COLORS[idx % DEFAULT_COLORS.length],
  }));

  return (
    <div className="space-y-6">
      {/* 4 Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Total Income */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Income</span>
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-bold text-emerald-600 tracking-tight">
            {formatINR(totalIncome)}
          </div>
          <div className="mt-2 text-xs text-slate-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>All recorded income</span>
          </div>
        </div>

        {/* Total Expenses */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Expenses</span>
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <TrendingDown className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-bold text-rose-600 tracking-tight">
            {formatINR(totalExpenses)}
          </div>
          <div className="mt-2 text-xs text-slate-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
            <span>All recorded spending</span>
          </div>
        </div>

        {/* Available Balance */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Available Balance</span>
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              availableBalance >= 0 ? 'bg-blue-50 text-blue-600' : 'bg-rose-50 text-rose-600'
            }`}>
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <div className={`text-2xl font-bold tracking-tight ${
            availableBalance >= 0 ? 'text-slate-900' : 'text-rose-600'
          }`}>
            {formatINR(availableBalance)}
          </div>
          <div className="mt-2 text-xs text-slate-400 flex items-center gap-1">
            <span className={`w-1.5 h-1.5 rounded-full ${availableBalance >= 0 ? 'bg-blue-500' : 'bg-rose-500'}`}></span>
            <span>Income minus expenses</span>
          </div>
        </div>

        {/* Total Transactions */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Transactions</span>
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Receipt className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900 tracking-tight">
            {totalTransactionCount}
          </div>
          <div className="mt-2 text-xs text-slate-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
            <span>Database entries</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Charts & Recent Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Category Expense Pie Chart (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">Expense Breakdown by Category</h3>
              <p className="text-xs text-slate-500">Visual distribution of all recorded expenses</p>
            </div>
          </div>

          {pieData.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center py-12 text-center text-slate-400">
              <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mb-3">
                <Receipt className="w-8 h-8 text-slate-300" />
              </div>
              <p className="text-sm font-medium text-slate-600">No expense records found</p>
              <p className="text-xs text-slate-400 mt-1 max-w-xs">
                Add your first expense transaction to view category distribution charts.
              </p>
              <button
                onClick={onNavigateToAdd}
                className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-semibold hover:bg-blue-700 transition"
              >
                <PlusCircle className="w-4 h-4" /> Add Expense
              </button>
            </div>
          ) : (
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={65}
                    outerRadius={95}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number) => [formatINR(value), 'Amount']}
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      borderRadius: '0.75rem',
                      border: 'none',
                      color: '#ffffff',
                      fontSize: '12px',
                    }}
                  />
                  <Legend
                    verticalAlign="bottom"
                    iconType="circle"
                    formatter={(value) => <span className="text-xs text-slate-600 font-medium">{value}</span>}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Five Most Recent Transactions (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">Recent Transactions</h3>
              <p className="text-xs text-slate-500">Five most recent database entries</p>
            </div>
            {recentTransactions.length > 0 && (
              <button
                onClick={onNavigateToHistory}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 transition"
              >
                View all <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {recentTransactions.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center py-12 text-center text-slate-400">
              <Clock className="w-10 h-10 text-slate-300 mb-2" />
              <p className="text-sm font-medium text-slate-600">No transactions recorded</p>
              <p className="text-xs text-slate-400 mt-1">Get started by logging your income or expenses</p>
              <button
                onClick={onNavigateToAdd}
                className="mt-4 inline-flex items-center gap-1 px-3.5 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-medium hover:bg-blue-700 transition"
              >
                <PlusCircle className="w-3.5 h-3.5" /> Add Transaction
              </button>
            </div>
          ) : (
            <div className="space-y-3 flex-1 overflow-y-auto">
              {recentTransactions.map((tx) => {
                const isIncome = tx.type === 'INCOME';
                return (
                  <div
                    key={tx.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-50 hover:bg-slate-100/80 transition-colors border border-slate-100"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div
                        className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                          isIncome ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'
                        }`}
                      >
                        {isIncome ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                      </div>
                      <div className="truncate">
                        <div className="text-sm font-semibold text-slate-900 truncate">
                          {tx.category}
                        </div>
                        <div className="text-xs text-slate-500 truncate">
                          {tx.description || formatDate(tx.transactionDate)}
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0 ml-3">
                      <div
                        className={`text-sm font-bold ${
                          isIncome ? 'text-emerald-600' : 'text-rose-600'
                        }`}
                      >
                        {isIncome ? '+' : '-'} {formatINR(tx.amount)}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {formatDate(tx.transactionDate)}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
