package com.expensetracker.service;

import com.expensetracker.dto.ChatRequest;
import com.expensetracker.dto.ChatResponse;
import com.expensetracker.model.TransactionType;
import com.expensetracker.repository.TransactionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

@Service
@Transactional(readOnly = true)
public class ChatAssistantService {

    private final TransactionRepository transactionRepository;

    private static final List<String> KNOWN_CATEGORIES = Arrays.asList(
            "Food", "Transport", "Education", "Shopping", "Entertainment", "Salary", "Allowance", "Other"
    );

    public ChatAssistantService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    public ChatResponse processMessage(ChatRequest request) {
        if (request == null || request.getMessage() == null || request.getMessage().trim().isEmpty()) {
            return new ChatResponse(
                    "Please ask a question about your expenses, income, balance, or transactions.",
                    "EMPTY"
            );
        }

        String raw = request.getMessage().trim();
        String lower = raw.toLowerCase(Locale.ENGLISH);

        LocalDate now = LocalDate.now();
        YearMonth currentYearMonth = YearMonth.from(now);
        LocalDate startOfMonth = currentYearMonth.atDay(1);
        LocalDate endOfMonth = currentYearMonth.atEndOfMonth();
        String currentMonthName = currentYearMonth.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " " + currentYearMonth.getYear();

        // 1. How much did I spend this month? / Monthly expense
        if ((lower.contains("spend") || lower.contains("spent") || lower.contains("expense"))
                && (lower.contains("this month") || lower.contains("current month"))) {
            BigDecimal monthlyExpenses = transactionRepository.sumAmountByTypeAndDateRange(TransactionType.EXPENSE, startOfMonth, endOfMonth);
            if (monthlyExpenses == null) monthlyExpenses = BigDecimal.ZERO;
            return new ChatResponse(
                    "You have spent " + formatCurrency(monthlyExpenses) + " in " + currentMonthName + ".",
                    "MONTHLY_EXPENSES"
            );
        }

        // 2. How much income did I receive this month? / Monthly income
        if ((lower.contains("income") || lower.contains("receive") || lower.contains("received") || lower.contains("earn") || lower.contains("earned"))
                && (lower.contains("this month") || lower.contains("current month"))) {
            BigDecimal monthlyIncome = transactionRepository.sumAmountByTypeAndDateRange(TransactionType.INCOME, startOfMonth, endOfMonth);
            if (monthlyIncome == null) monthlyIncome = BigDecimal.ZERO;
            return new ChatResponse(
                    "You received " + formatCurrency(monthlyIncome) + " in income during " + currentMonthName + ".",
                    "MONTHLY_INCOME"
            );
        }

        // 3. What is my current balance? / Available balance
        if (lower.contains("balance") || lower.contains("available money") || lower.contains("remaining")) {
            BigDecimal totalIncome = transactionRepository.sumAmountByType(TransactionType.INCOME);
            BigDecimal totalExpenses = transactionRepository.sumAmountByType(TransactionType.EXPENSE);
            if (totalIncome == null) totalIncome = BigDecimal.ZERO;
            if (totalExpenses == null) totalExpenses = BigDecimal.ZERO;
            BigDecimal balance = totalIncome.subtract(totalExpenses);

            return new ChatResponse(
                    "Your current available balance is " + formatCurrency(balance) + " (Income: " + formatCurrency(totalIncome) + ", Expenses: " + formatCurrency(totalExpenses) + ").",
                    "CURRENT_BALANCE"
            );
        }

        // 4. Which category did I spend the most on? / Highest spending category
        if ((lower.contains("category") || lower.contains("what") || lower.contains("which"))
                && (lower.contains("most") || lower.contains("highest") || lower.contains("maximum"))) {
            List<Object[]> categorySums = transactionRepository.sumAmountGroupedByCategory(TransactionType.EXPENSE);
            if (categorySums.isEmpty()) {
                return new ChatResponse(
                        "You haven't recorded any expenses yet.",
                        "HIGHEST_CATEGORY"
                );
            }
            Object[] top = categorySums.get(0);
            String category = (String) top[0];
            BigDecimal amount = (BigDecimal) top[1];
            return new ChatResponse(
                    "You spent the most on " + category + " with a total of " + formatCurrency(amount) + ".",
                    "HIGHEST_CATEGORY"
            );
        }

        // 5. How much did I spend on [category]?
        for (String cat : KNOWN_CATEGORIES) {
            if (lower.contains(cat.toLowerCase(Locale.ENGLISH))) {
                BigDecimal catExpenses = transactionRepository.sumAmountByTypeAndCategory(TransactionType.EXPENSE, cat);
                if (catExpenses == null) catExpenses = BigDecimal.ZERO;
                return new ChatResponse(
                        "You have spent a total of " + formatCurrency(catExpenses) + " on " + cat + ".",
                        "CATEGORY_EXPENSE"
                );
            }
        }

        // 6. What are my total expenses?
        if (lower.contains("total expense") || lower.contains("total expenses") || lower.contains("overall expense")
                || (lower.contains("total") && (lower.contains("spend") || lower.contains("spent")))) {
            BigDecimal totalExpenses = transactionRepository.sumAmountByType(TransactionType.EXPENSE);
            if (totalExpenses == null) totalExpenses = BigDecimal.ZERO;
            return new ChatResponse(
                    "Your total expenses across all time are " + formatCurrency(totalExpenses) + ".",
                    "TOTAL_EXPENSES"
            );
        }

        // 7. Total income all time
        if (lower.contains("total income") || lower.contains("overall income")) {
            BigDecimal totalIncome = transactionRepository.sumAmountByType(TransactionType.INCOME);
            if (totalIncome == null) totalIncome = BigDecimal.ZERO;
            return new ChatResponse(
                    "Your total recorded income across all time is " + formatCurrency(totalIncome) + ".",
                    "TOTAL_INCOME"
            );
        }

        // 8. How many transactions do I have?
        if (lower.contains("how many transaction") || lower.contains("number of transaction") || lower.contains("total transaction")) {
            long count = transactionRepository.count();
            return new ChatResponse(
                    "You have a total of " + count + " transaction" + (count == 1 ? "" : "s") + " recorded.",
                    "TRANSACTION_COUNT"
            );
        }

        // Polite fallback explaining capabilities
        return new ChatResponse(
                "I can help you answer questions about your financial data! Try asking:\n"
                        + "• How much did I spend this month?\n"
                        + "• What is my current balance?\n"
                        + "• How much income did I receive this month?\n"
                        + "• Which category did I spend the most on?\n"
                        + "• How much did I spend on food? (or Transport, Shopping, etc.)\n"
                        + "• What are my total expenses?\n"
                        + "• How many transactions do I have?",
                "UNSUPPORTED"
        );
    }

    private String formatCurrency(BigDecimal amount) {
        if (amount == null) amount = BigDecimal.ZERO;
        NumberFormat nf = NumberFormat.getNumberInstance(new Locale("en", "IN"));
        nf.setMinimumFractionDigits(2);
        nf.setMaximumFractionDigits(2);
        return "₹" + nf.format(amount);
    }
}
