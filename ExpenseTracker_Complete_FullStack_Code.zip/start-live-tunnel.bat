@echo off
call "%~dp0deploy-live-tunnel.bat"
