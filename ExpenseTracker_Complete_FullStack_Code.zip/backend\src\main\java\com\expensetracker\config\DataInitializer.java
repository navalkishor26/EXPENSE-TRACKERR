package com.expensetracker.config;

import com.expensetracker.model.Transaction;
import com.expensetracker.model.TransactionType;
import com.expensetracker.repository.TransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;

@Component
public class DataInitializer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);
    private final TransactionRepository transactionRepository;

    public DataInitializer(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (transactionRepository.count() == 0) {
            log.info("Database is empty. Seeding initial demo transactions...");

            LocalDate now = LocalDate.now();
            int currentYear = now.getYear();
            int currentMonth = now.getMonthValue();

            Transaction t1 = new Transaction(
                    TransactionType.INCOME,
                    new BigDecimal("65000.00"),
                    "Salary",
                    "Monthly Salary Credited",
                    LocalDate.of(currentYear, currentMonth, 1)
            );

            Transaction t2 = new Transaction(
                    TransactionType.EXPENSE,
                    new BigDecimal("3500.00"),
                    "Food",
                    "Grocery shopping at DMart",
                    LocalDate.of(currentYear, currentMonth, 4)
            );

            Transaction t3 = new Transaction(
                    TransactionType.EXPENSE,
                    new BigDecimal("1200.00"),
                    "Transport",
                    "Monthly Metro card recharge",
                    LocalDate.of(currentYear, currentMonth, 8)
            );

            Transaction t4 = new Transaction(
                    TransactionType.EXPENSE,
                    new BigDecimal("4500.00"),
                    "Education",
                    "Cloud Computing Certification Course",
                    LocalDate.of(currentYear, currentMonth, 12)
            );

            Transaction t5 = new Transaction(
                    TransactionType.EXPENSE,
                    new BigDecimal("2800.00"),
                    "Entertainment",
                    "Weekend dinner and movie with friends",
                    LocalDate.of(currentYear, currentMonth, 18)
            );

            Transaction t6 = new Transaction(
                    TransactionType.EXPENSE,
                    new BigDecimal("1850.00"),
                    "Shopping",
                    "Electronics & Project Components",
                    LocalDate.of(currentYear, currentMonth, 22)
            );

            Transaction t7 = new Transaction(
                    TransactionType.INCOME,
                    new BigDecimal("5000.00"),
                    "Allowance",
                    "Academic Project Stipend",
                    LocalDate.of(currentYear, currentMonth, 25)
            );

            transactionRepository.saveAll(Arrays.asList(t1, t2, t3, t4, t5, t6, t7));
            log.info("Successfully seeded 7 demo transactions!");
        }
    }
}
