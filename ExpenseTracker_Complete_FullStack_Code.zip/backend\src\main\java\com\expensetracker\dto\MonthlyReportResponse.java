package com.expensetracker.dto;

import java.math.BigDecimal;
import java.util.List;

public class MonthlyReportResponse {

    private int month;
    private int year;
    private BigDecimal monthlyIncome;
    private BigDecimal monthlyExpenses;
    private BigDecimal monthlyBalance;
    private List<CategoryExpenseDTO> categoryExpenses;
    private String highestSpendingCategory;
    private BigDecimal highestSpendingAmount;

    public MonthlyReportResponse() {}

    public MonthlyReportResponse(int month, int year, BigDecimal monthlyIncome, BigDecimal monthlyExpenses,
                                 BigDecimal monthlyBalance, List<CategoryExpenseDTO> categoryExpenses,
                                 String highestSpendingCategory, BigDecimal highestSpendingAmount) {
        this.month = month;
        this.year = year;
        this.monthlyIncome = monthlyIncome;
        this.monthlyExpenses = monthlyExpenses;
        this.monthlyBalance = monthlyBalance;
        this.categoryExpenses = categoryExpenses;
        this.highestSpendingCategory = highestSpendingCategory;
        this.highestSpendingAmount = highestSpendingAmount;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public BigDecimal getMonthlyIncome() {
        return monthlyIncome;
    }

    public void setMonthlyIncome(BigDecimal monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public BigDecimal getMonthlyExpenses() {
        return monthlyExpenses;
    }

    public void setMonthlyExpenses(BigDecimal monthlyExpenses) {
        this.monthlyExpenses = monthlyExpenses;
    }

    public BigDecimal getMonthlyBalance() {
        return monthlyBalance;
    }

    public void setMonthlyBalance(BigDecimal monthlyBalance) {
        this.monthlyBalance = monthlyBalance;
    }

    public List<CategoryExpenseDTO> getCategoryExpenses() {
        return categoryExpenses;
    }

    public void setCategoryExpenses(List<CategoryExpenseDTO> categoryExpenses) {
        this.categoryExpenses = categoryExpenses;
    }

    public String getHighestSpendingCategory() {
        return highestSpendingCategory;
    }

    public void setHighestSpendingCategory(String highestSpendingCategory) {
        this.highestSpendingCategory = highestSpendingCategory;
    }

    public BigDecimal getHighestSpendingAmount() {
        return highestSpendingAmount;
    }

    public void setHighestSpendingAmount(BigDecimal highestSpendingAmount) {
        this.highestSpendingAmount = highestSpendingAmount;
    }
}
