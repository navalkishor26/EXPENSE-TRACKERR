# 💰 Expense Tracker Web Application (B.Tech Final Project)

A clean, modern, and fully functional full-stack Expense Tracker web application built using **Java 21**, **Spring Boot**, **Spring Data JPA**, **MySQL**, **React**, **TypeScript**, and **Tailwind CSS**.

---

## 📋 Technology Stack

* **Frontend:** React 18, TypeScript, Tailwind CSS, Lucide React
* **Data Visualization & Charts:** Recharts (Responsive Pie & Bar charts)
* **HTTP Client:** Axios with centralized API layer
* **Backend:** Java 21, Spring Boot 3.2.5, Spring Data JPA, Hibernate
* **Database:** MySQL 8.x (with automated schema generation & in-memory test support)
* **Monetary Precision:** `BigDecimal` used for currency calculations to prevent floating-point rounding errors
* **Build Systems:** Maven (`mvn`) and Node Package Manager (`npm`)

---

## 🚀 The 5 Core Features

1. **Dashboard**
   * Real-time calculation of Total Income, Total Expenses, and Available Balance.
   * Total transaction counter.
   * Interactive Category Expense Pie Chart with color-coded categories and percentages.
   * Recent 5 transactions quick list.

2. **Add Income & Expenses**
   * Form with type toggle (Income / Expense).
   * Monetary amount validation (rejects `<= 0`).
   * Category selector: *Food, Transport, Education, Shopping, Entertainment, Salary, Allowance, Other*.
   * Date selection and optional description.
   * Saves directly to MySQL database.

3. **Transaction History**
   * Complete paginated/filtered list of all transactions sorted newest first (`DESC`).
   * Multi-criteria filters: Filter by Type (*Income / Expense / All*) and Category (*Food, Transport, etc.*).
   * **Edit Modal:** Edit amount, category, date, type, and description with real-time DB persistence.
   * **Delete Modal:** Modal confirmation before permanent deletion.

4. **Monthly Expense Summary**
   * Month (1-12) and Year selector.
   * Monthly Income, Monthly Expense, and Net Balance calculation.
   * Income vs Expenses comparison bar chart.
   * Category-wise breakdown list with progress bars, spent amounts, and percentages.
   * Highlight banner for the highest-spending category of the selected month.

5. **Chat Assistant (Rule-Based AI in Java)**
   * Built-in Java rule engine in Spring Boot answering financial queries from database records:
     * *"How much did I spend this month?"*
     * *"What is my current balance?"*
     * *"How much income did I receive this month?"*
     * *"Which category did I spend the most on?"*
     * *"How much did I spend on food?"* (or Transport, Shopping, Entertainment, etc.)
     * *"What are my total expenses?"*
     * *"How many transactions do I have?"*
   * Polite fallback guidance when an unsupported question is asked.

---

## 📂 Project Structure

```
expenssssss/
├── backend/
│   ├── pom.xml                               # Maven project definition
│   └── src/
│       ├── main/
│       │   ├── java/com/expensetracker/
│       │   │   ├── ExpenseTrackerApplication.java
│       │   │   ├── config/
│       │   │   │   ├── CorsConfig.java       # Cross-Origin Resource Sharing
│       │   │   │   └── DataInitializer.java  # Seeds initial demo data if DB is empty
│       │   │   ├── controller/
│       │   │   │   ├── TransactionController.java
│       │   │   │   ├── DashboardController.java
│       │   │   │   ├── ReportController.java
│       │   │   │   ├── ChatAssistantController.java
│       │   │   │   └── HealthController.java
│       │   │   ├── dto/                      # Data Transfer Objects
│       │   │   ├── exception/                # Centralized Exception Handling
│       │   │   ├── model/                    # JPA Entities & Enums
│       │   │   ├── repository/               # Spring Data JPA Repository
│       │   │   └── service/                  # Business Logic Services
│       │   └── resources/
│       │       ├── application.properties    # MySQL configuration (default)
│       │       └── application-h2.properties # In-memory fallback profile
│       └── test/                             # Automated test suite (20 tests)
├── frontend/
│   ├── package.json
│   ├── tsconfig.json
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   ├── src/
│   │   ├── api/client.ts                     # Axios API service
│   │   ├── components/
│   │   │   ├── Sidebar.tsx                   # Dark blue responsive sidebar
│   │   │   ├── Navbar.tsx                    # Header with INR indicator
│   │   │   ├── DashboardView.tsx             # Feature 1
│   │   │   ├── AddTransactionView.tsx        # Feature 2
│   │   │   ├── TransactionHistoryView.tsx    # Feature 3
│   │   │   ├── MonthlySummaryView.tsx        # Feature 4
│   │   │   └── ChatAssistantView.tsx         # Feature 5
│   │   ├── types/index.ts                    # TypeScript types
│   │   └── utils/formatters.ts               # Currency (₹ INR) & Date helpers
└── README.md
```

---

## ⚙️ Prerequisites

1. **Java JDK 21**: Verify with `java -version`
2. **Apache Maven 3.8+**: Verify with `mvn -v`
3. **Node.js 18+ and npm**: Verify with `node -v` and `npm -v`
4. **MySQL Server 8.0+** running on `localhost:3306`

*(Note: Portable Java 21, Maven 3.9.6, and Node.js are bundled in the `tools/` folder for convenience if local environment paths are not configured).*

---

## 🗄️ Database Setup (MySQL)

1. Start your local MySQL service (via XAMPP, MySQL Workbench, or Windows Service).
2. Create the database:
   ```sql
   CREATE DATABASE IF NOT EXISTS expense_tracker;
   ```
3. Update database credentials if needed in `backend/src/main/resources/application.properties`:
   ```properties
   spring.datasource.url=jdbc:mysql://localhost:3306/expense_tracker?createDatabaseIfNotExist=true
   spring.datasource.username=root
   spring.datasource.password=your_password
   ```

---

## 🚀 Running the Project

### 1. Start the Java Spring Boot Backend

Open a terminal in the `backend/` directory:

```bash
# If using standard system Maven:
mvn spring-boot:run

# Or with custom DB credentials passed via environment:
mvn spring-boot:run -Dspring-boot.run.arguments="--DB_USERNAME=root --DB_PASSWORD=your_password"

# Optional: To run without local MySQL using the in-memory H2 profile:
mvn spring-boot:run -Dspring-boot.run.profiles=h2
```

The backend server will start at: **`http://localhost:8080`**

### 2. Start the React Frontend

Open a second terminal in the `frontend/` directory:

```bash
# Install dependencies (already installed if using workspace):
npm install

# Start Vite development server:
npm run dev
```

Open your browser at: **`http://localhost:5173`**

### 3. Instant Live Public Deployment (Share Online)

To share your running app with anyone over the internet (mobile, viva, external reviewers) without any account or signup:

Double-click **`deploy-live-tunnel.bat`** (or `start-live-tunnel.bat`).

It will start a secure HTTPS tunnel and give you an instant public URL:
```
https://<random-name>.trycloudflare.com
```
Anyone can open this link to access the live app, complete with backend API operations and database support!

---

## 🧪 Automated Testing

To run the comprehensive backend test suite (20 automated tests verifying validation, CRUD operations, database calculations, monthly aggregations, and rule-based chat queries):

```bash
cd backend
mvn test
```

**Results:**
* `TransactionControllerTest`: 7 tests passing (CRUD, validation, 404 handling, type/category filters).
* `DashboardServiceTest`: 2 tests passing (summary calculations, empty state, percentages).
* `ReportServiceTest`: 3 tests passing (monthly date ranges, highest spending category).
* `ChatAssistantServiceTest`: 8 tests passing (all 7 required queries + fallback handling).

To verify the TypeScript frontend build:

```bash
cd frontend
npm run build
```

---

## 🔌 API Endpoints Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Healthcheck and database connection status |
| `GET` | `/api/dashboard/summary` | Financial summary, counts, pie chart data, top 5 recent |
| `GET` | `/api/transactions` | List all transactions with optional `?type=` and `?category=` |
| `POST` | `/api/transactions` | Create a transaction (validates amount > 0, required fields) |
| `GET` | `/api/transactions/{id}` | Get single transaction |
| `PUT` | `/api/transactions/{id}` | Update existing transaction |
| `DELETE` | `/api/transactions/{id}` | Delete transaction |
| `GET` | `/api/reports/monthly?month=10&year=2026` | Monthly income, expenses, balance, bar chart, top category |
| `POST` | `/api/assistant/chat` | Send question to rule-based assistant; returns database-driven answer |

---

## 🎓 College Project Viva / Demo Tips

1. **Why `BigDecimal`?**
   * Explain that `double` or `float` introduces IEEE-754 precision errors (e.g. `0.1 + 0.2 = 0.30000000000000004`), which is unacceptable in banking and financial software.
2. **How does the Chat Assistant work?**
   * Explain that it is an efficient, deterministic rule-based natural language processor in Java that parses user queries, identifies financial intents, queries the JPA repository dynamically, and formats responses with Indian Rupees.
3. **Database Relationships & Integrity:**
   * JPA automatically maps entities with `@PrePersist` to ensure timestamps and integrity are maintained.
