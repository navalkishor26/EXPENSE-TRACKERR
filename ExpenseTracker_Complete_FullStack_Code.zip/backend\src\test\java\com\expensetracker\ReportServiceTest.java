package com.expensetracker;

import com.expensetracker.dto.MonthlyReportResponse;
import com.expensetracker.model.Transaction;
import com.expensetracker.model.TransactionType;
import com.expensetracker.repository.TransactionRepository;
import com.expensetracker.service.ReportService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
public class ReportServiceTest {

    @Autowired
    private ReportService reportService;

    @Autowired
    private TransactionRepository transactionRepository;

    @BeforeEach
    void setUp() {
        transactionRepository.deleteAll();
    }

    @Test
    void testMonthlyReport_EmptyMonth() {
        MonthlyReportResponse report = reportService.getMonthlyReport(10, 2026);
        assertNotNull(report);
        assertEquals(10, report.getMonth());
        assertEquals(2026, report.getYear());
        assertEquals(BigDecimal.ZERO, report.getMonthlyIncome());
        assertEquals(BigDecimal.ZERO, report.getMonthlyExpenses());
        assertEquals(BigDecimal.ZERO, report.getMonthlyBalance());
        assertNull(report.getHighestSpendingCategory());
        assertEquals(BigDecimal.ZERO, report.getHighestSpendingAmount());
    }

    @Test
    void testMonthlyReport_WithDataAcrossMonths() {
        // September 2026
        transactionRepository.save(new Transaction(
                TransactionType.INCOME, new BigDecimal("40000.00"), "Salary", "Sep Salary", LocalDate.of(2026, 9, 30)));
        transactionRepository.save(new Transaction(
                TransactionType.EXPENSE, new BigDecimal("5000.00"), "Shopping", "Clothes", LocalDate.of(2026, 9, 15)));

        // October 2026
        transactionRepository.save(new Transaction(
                TransactionType.INCOME, new BigDecimal("60000.00"), "Salary", "Oct Salary", LocalDate.of(2026, 10, 1)));
        transactionRepository.save(new Transaction(
                TransactionType.EXPENSE, new BigDecimal("3500.00"), "Food", "Groceries", LocalDate.of(2026, 10, 10)));
        transactionRepository.save(new Transaction(
                TransactionType.EXPENSE, new BigDecimal("1500.00"), "Transport", "Fuel", LocalDate.of(2026, 10, 12)));
        transactionRepository.save(new Transaction(
                TransactionType.EXPENSE, new BigDecimal("7000.00"), "Education", "Course Fee", LocalDate.of(2026, 10, 18)));

        // Check September Report
        MonthlyReportResponse sepReport = reportService.getMonthlyReport(9, 2026);
        assertEquals(0, new BigDecimal("40000.00").compareTo(sepReport.getMonthlyIncome()));
        assertEquals(0, new BigDecimal("5000.00").compareTo(sepReport.getMonthlyExpenses()));
        assertEquals(0, new BigDecimal("35000.00").compareTo(sepReport.getMonthlyBalance()));
        assertEquals("Shopping", sepReport.getHighestSpendingCategory());
        assertEquals(0, new BigDecimal("5000.00").compareTo(sepReport.getHighestSpendingAmount()));

        // Check October Report
        MonthlyReportResponse octReport = reportService.getMonthlyReport(10, 2026);
        assertEquals(0, new BigDecimal("60000.00").compareTo(octReport.getMonthlyIncome()));
        assertEquals(0, new BigDecimal("12000.00").compareTo(octReport.getMonthlyExpenses()));
        assertEquals(0, new BigDecimal("48000.00").compareTo(octReport.getMonthlyBalance()));
        assertEquals("Education", octReport.getHighestSpendingCategory());
        assertEquals(0, new BigDecimal("7000.00").compareTo(octReport.getHighestSpendingAmount()));
        assertEquals(3, octReport.getCategoryExpenses().size());
    }

    @Test
    void testMonthlyReport_InvalidMonthThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> reportService.getMonthlyReport(13, 2026));
        assertThrows(IllegalArgumentException.class, () -> reportService.getMonthlyReport(0, 2026));
    }
}
