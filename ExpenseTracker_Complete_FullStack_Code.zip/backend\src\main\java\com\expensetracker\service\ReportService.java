package com.expensetracker.service;

import com.expensetracker.dto.CategoryExpenseDTO;
import com.expensetracker.dto.MonthlyReportResponse;
import com.expensetracker.model.TransactionType;
import com.expensetracker.repository.TransactionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional(readOnly = true)
public class ReportService {

    private final TransactionRepository transactionRepository;

    public ReportService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    public MonthlyReportResponse getMonthlyReport(int month, int year) {
        if (month < 1 || month > 12) {
            throw new IllegalArgumentException("Month must be between 1 and 12");
        }
        if (year < 2000 || year > 2100) {
            throw new IllegalArgumentException("Year must be between 2000 and 2100");
        }

        YearMonth yearMonth = YearMonth.of(year, month);
        LocalDate startDate = yearMonth.atDay(1);
        LocalDate endDate = yearMonth.atEndOfMonth();

        BigDecimal monthlyIncome = transactionRepository.sumAmountByTypeAndDateRange(TransactionType.INCOME, startDate, endDate);
        if (monthlyIncome == null) {
            monthlyIncome = BigDecimal.ZERO;
        }

        BigDecimal monthlyExpenses = transactionRepository.sumAmountByTypeAndDateRange(TransactionType.EXPENSE, startDate, endDate);
        if (monthlyExpenses == null) {
            monthlyExpenses = BigDecimal.ZERO;
        }

        BigDecimal monthlyBalance = monthlyIncome.subtract(monthlyExpenses);

        List<Object[]> rawCategories = transactionRepository.sumAmountGroupedByCategoryAndDateRange(TransactionType.EXPENSE, startDate, endDate);
        List<CategoryExpenseDTO> categoryExpenses = new ArrayList<>();

        String highestCategory = null;
        BigDecimal highestAmount = BigDecimal.ZERO;

        for (Object[] row : rawCategories) {
            String category = (String) row[0];
            BigDecimal amount = (BigDecimal) row[1];
            double percentage = 0.0;
            if (monthlyExpenses.compareTo(BigDecimal.ZERO) > 0) {
                percentage = amount.divide(monthlyExpenses, 4, RoundingMode.HALF_UP)
                        .multiply(BigDecimal.valueOf(100))
                        .setScale(2, RoundingMode.HALF_UP)
                        .doubleValue();
            }
            categoryExpenses.add(new CategoryExpenseDTO(category, amount, percentage));

            if (highestCategory == null || amount.compareTo(highestAmount) > 0) {
                highestCategory = category;
                highestAmount = amount;
            }
        }

        return new MonthlyReportResponse(
                month,
                year,
                monthlyIncome,
                monthlyExpenses,
                monthlyBalance,
                categoryExpenses,
                highestCategory,
                highestAmount
        );
    }
}
