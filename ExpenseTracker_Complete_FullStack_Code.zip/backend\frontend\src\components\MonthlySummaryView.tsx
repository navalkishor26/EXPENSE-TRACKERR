import React, { useEffect, useState } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  Award,
  AlertCircle,
  BarChart3,
  Calendar,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import { api } from '../api/client';
import { MonthlyReport } from '../types';
import { formatINR } from '../utils/formatters';

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

const YEARS = [2024, 2025, 2026, 2027];

export const MonthlySummaryView: React.FC = () => {
  const currentDate = new Date();
  const [selectedMonth, setSelectedMonth] = useState<number>(currentDate.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState<number>(currentDate.getFullYear());

  const [report, setReport] = useState<MonthlyReport | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMonthlyReport = async (month: number, year: number) => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getMonthlyReport(month, year);
      setReport(data);
    } catch (err: unknown) {
      if (err instanceof Error) {
        setError(err.message || 'Failed to fetch monthly report');
      } else {
        setError('Failed to fetch monthly report');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMonthlyReport(selectedMonth, selectedYear);
  }, [selectedMonth, selectedYear]);

  const {
    monthlyIncome = 0,
    monthlyExpenses = 0,
    monthlyBalance = 0,
    categoryExpenses = [],
    highestSpendingCategory = null,
    highestSpendingAmount = 0,
  } = report || {};

  // Comparison Bar Chart Data
  const comparisonData = [
    { name: 'Income', amount: Number(monthlyIncome), color: '#10b981' },
    { name: 'Expenses', amount: Number(monthlyExpenses), color: '#ef4444' },
  ];

  return (
    <div className="space-y-6">
      {/* Month & Year Selector Card */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-2.5 text-slate-800">
          <Calendar className="w-5 h-5 text-blue-600" />
          <h3 className="font-bold text-sm">Select Billing Period</h3>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          {/* Month selector */}
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(Number(e.target.value))}
            className="px-3.5 py-2 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {MONTH_NAMES.map((m, idx) => (
              <option key={m} value={idx + 1}>
                {m}
              </option>
            ))}
          </select>

          {/* Year selector */}
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="px-3.5 py-2 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {YEARS.map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </div>
      </div>

      {loading ? (
        <div className="p-16 text-center">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-sm text-slate-500 font-medium">
            Fetching report for {MONTH_NAMES[selectedMonth - 1]} {selectedYear}...
          </p>
        </div>
      ) : error ? (
        <div className="p-8 text-center text-rose-600 bg-rose-50 rounded-2xl border border-rose-200">
          <AlertCircle className="w-8 h-8 text-rose-500 mx-auto mb-2" />
          <p className="font-semibold text-sm">{error}</p>
        </div>
      ) : (
        <>
          {/* Monthly KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            {/* Monthly Income */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Monthly Income
                </span>
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <TrendingUp className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-bold text-emerald-600 tracking-tight">
                {formatINR(monthlyIncome)}
              </div>
              <div className="mt-2 text-xs text-slate-400">
                Total for {MONTH_NAMES[selectedMonth - 1]}
              </div>
            </div>

            {/* Monthly Expenses */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Monthly Expenses
                </span>
                <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
                  <TrendingDown className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-bold text-rose-600 tracking-tight">
                {formatINR(monthlyExpenses)}
              </div>
              <div className="mt-2 text-xs text-slate-400">
                Total for {MONTH_NAMES[selectedMonth - 1]}
              </div>
            </div>

            {/* Monthly Net Balance */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Monthly Net Balance
                </span>
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  monthlyBalance >= 0 ? 'bg-blue-50 text-blue-600' : 'bg-rose-50 text-rose-600'
                }`}>
                  <Wallet className="w-4 h-4" />
                </div>
              </div>
              <div className={`text-2xl font-bold tracking-tight ${
                monthlyBalance >= 0 ? 'text-slate-900' : 'text-rose-600'
              }`}>
                {formatINR(monthlyBalance)}
              </div>
              <div className="mt-2 text-xs text-slate-400">
                Net savings this month
              </div>
            </div>
          </div>

          {/* Highest Spending Category Highlight Banner */}
          {highestSpendingCategory ? (
            <div className="bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-300/60 rounded-2xl p-5 flex items-center justify-between">
              <div className="flex items-center space-x-3.5">
                <div className="w-11 h-11 rounded-xl bg-amber-500 text-white flex items-center justify-center shadow-md shadow-amber-500/30">
                  <Award className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wider text-amber-800">
                    Highest Spending Category
                  </div>
                  <div className="text-lg font-bold text-slate-900">
                    {highestSpendingCategory}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-500 font-medium">Spent in {MONTH_NAMES[selectedMonth - 1]}</div>
                <div className="text-lg font-bold text-amber-700">
                  {formatINR(highestSpendingAmount)}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 text-center text-xs text-slate-500">
              No expenses recorded in {MONTH_NAMES[selectedMonth - 1]} {selectedYear}.
            </div>
          )}

          {/* Charts & Breakdown Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Bar Chart: Income vs Expenses (6 cols) */}
            <div className="lg:col-span-6 bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-col">
              <div className="mb-4">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-blue-600" />
                  Income vs Expenses Comparison
                </h3>
                <p className="text-xs text-slate-500">
                  Direct comparison for {MONTH_NAMES[selectedMonth - 1]} {selectedYear}
                </p>
              </div>

              <div className="h-64 w-full flex-1">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={comparisonData} margin={{ top: 20, right: 20, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} />
                    <YAxis
                      stroke="#64748b"
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(val) => `₹${val}`}
                    />
                    <Tooltip
                      formatter={(val: number) => [formatINR(val), 'Amount']}
                      contentStyle={{
                        backgroundColor: '#0f172a',
                        borderRadius: '0.75rem',
                        border: 'none',
                        color: '#ffffff',
                        fontSize: '12px',
                      }}
                    />
                    <Bar dataKey="amount" radius={[8, 8, 0, 0]} maxBarSize={60}>
                      {comparisonData.map((entry, index) => (
                        <Cell key={`bar-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Category-Wise Expense List (6 cols) */}
            <div className="lg:col-span-6 bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-col">
              <div className="mb-4">
                <h3 className="text-base font-bold text-slate-900">Category-Wise Expenses</h3>
                <p className="text-xs text-slate-500">Distribution across categories for this month</p>
              </div>

              {categoryExpenses.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center text-center py-10 text-slate-400">
                  <p className="text-sm font-medium text-slate-600">No monthly expenses</p>
                  <p className="text-xs text-slate-400 mt-1">There are no expense records logged in this month.</p>
                </div>
              ) : (
                <div className="space-y-4 flex-1 overflow-y-auto">
                  {categoryExpenses.map((cat) => (
                    <div key={cat.category} className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-800">{cat.category}</span>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900">{formatINR(cat.amount)}</span>
                          <span className="text-slate-400 font-medium">({cat.percentage}%)</span>
                        </div>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                        <div
                          className="h-full bg-rose-500 rounded-full transition-all duration-500"
                          style={{ width: `${Math.min(cat.percentage, 100)}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};
