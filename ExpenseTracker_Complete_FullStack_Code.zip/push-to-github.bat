@echo off
setlocal enabledelayedexpansion
title GitHub Publisher

echo ===================================================
echo     Expense Tracker - Push to GitHub Helper
echo ===================================================
echo.
echo Make sure you have created an empty repository on GitHub first!
echo (e.g. https://github.com/new)
echo.

set /p REPO_URL="Enter your GitHub Repository URL (e.g., https://github.com/username/expense-tracker.git): "

if "%REPO_URL%"=="" (
    echo Error: Repository URL cannot be empty!
    pause
    exit /b 1
)

echo.
echo [1/4] Staging changes and committing...
git add .
git commit -m "Configure full-stack deployment" 2>nul

echo [2/4] Setting branch to main...
git branch -M main

echo [3/4] Adding remote origin...
git remote remove origin 2>nul
git remote add origin %REPO_URL%

echo [4/4] Pushing code to GitHub...
git push -u origin main

if %errorlevel% equ 0 (
    echo.
    echo ===================================================
    echo  SUCCESS! Your code has been posted to GitHub!
    echo ===================================================
) else (
    echo.
    echo ===================================================
    echo  Push failed. Please check your URL and GitHub credentials.
    echo ===================================================
)

echo.
pause
