package com.expensetracker.dto;

public class ChatResponse {

    private String reply;
    private String intent;

    public ChatResponse() {}

    public ChatResponse(String reply, String intent) {
        this.reply = reply;
        this.intent = intent;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public String getIntent() {
        return intent;
    }

    public void setIntent(String intent) {
        this.intent = intent;
    }
}
