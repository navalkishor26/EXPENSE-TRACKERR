import { useState } from 'react';
import { Sidebar, TabType } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { AddTransactionView } from './components/AddTransactionView';
import { TransactionHistoryView } from './components/TransactionHistoryView';
import { MonthlySummaryView } from './components/MonthlySummaryView';
import { ChatAssistantView } from './components/ChatAssistantView';

export function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar (Dark blue) */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col lg:pl-72 min-w-0">
        {/* Navbar */}
        <Navbar
          activeTab={activeTab}
          onOpenSidebar={() => setSidebarOpen(true)}
        />

        {/* View Switcher */}
        <main className="flex-1 p-4 sm:p-8 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <DashboardView
              onNavigateToAdd={() => setActiveTab('add')}
              onNavigateToHistory={() => setActiveTab('history')}
            />
          )}

          {activeTab === 'add' && (
            <AddTransactionView
              onSuccess={() => {
                // optionally switch to dashboard or keep for another entry
              }}
            />
          )}

          {activeTab === 'history' && <TransactionHistoryView />}

          {activeTab === 'monthly' && <MonthlySummaryView />}

          {activeTab === 'chat' && <ChatAssistantView />}
        </main>
      </div>
    </div>
  );
}

export default App;
