package com.expensetracker;

import com.expensetracker.dto.DashboardSummaryResponse;
import com.expensetracker.model.Transaction;
import com.expensetracker.model.TransactionType;
import com.expensetracker.repository.TransactionRepository;
import com.expensetracker.service.DashboardService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
public class DashboardServiceTest {

    @Autowired
    private DashboardService dashboardService;

    @Autowired
    private TransactionRepository transactionRepository;

    @BeforeEach
    void setUp() {
        transactionRepository.deleteAll();
    }

    @Test
    void testEmptyDatabaseSummary() {
        DashboardSummaryResponse summary = dashboardService.getDashboardSummary();
        assertNotNull(summary);
        assertEquals(BigDecimal.ZERO, summary.getTotalIncome());
        assertEquals(BigDecimal.ZERO, summary.getTotalExpenses());
        assertEquals(BigDecimal.ZERO, summary.getAvailableBalance());
        assertEquals(0, summary.getTotalTransactionCount());
        assertTrue(summary.getCategoryExpenses().isEmpty());
        assertTrue(summary.getRecentTransactions().isEmpty());
    }

    @Test
    void testDashboardCalculationsWithData() {
        // Income: 50,000
        transactionRepository.save(new Transaction(
                TransactionType.INCOME, new BigDecimal("50000.00"), "Salary", "Salary", LocalDate.of(2026, 10, 1)));

        // Expense 1: Food 2000
        transactionRepository.save(new Transaction(
                TransactionType.EXPENSE, new BigDecimal("2000.00"), "Food", "Groceries", LocalDate.of(2026, 10, 5)));

        // Expense 2: Transport 1000
        transactionRepository.save(new Transaction(
                TransactionType.EXPENSE, new BigDecimal("1000.00"), "Transport", "Metro", LocalDate.of(2026, 10, 8)));

        // Expense 3: Food 1000
        transactionRepository.save(new Transaction(
                TransactionType.EXPENSE, new BigDecimal("1000.00"), "Food", "Dinner", LocalDate.of(2026, 10, 15)));

        DashboardSummaryResponse summary = dashboardService.getDashboardSummary();
        assertNotNull(summary);
        assertEquals(0, new BigDecimal("50000.00").compareTo(summary.getTotalIncome()));
        assertEquals(0, new BigDecimal("4000.00").compareTo(summary.getTotalExpenses()));
        assertEquals(0, new BigDecimal("46000.00").compareTo(summary.getAvailableBalance()));
        assertEquals(4, summary.getTotalTransactionCount());

        // Category breakdown: Food = 3000 (75%), Transport = 1000 (25%)
        assertEquals(2, summary.getCategoryExpenses().size());
        assertEquals("Food", summary.getCategoryExpenses().get(0).getCategory());
        assertEquals(0, new BigDecimal("3000.00").compareTo(summary.getCategoryExpenses().get(0).getAmount()));
        assertEquals(75.0, summary.getCategoryExpenses().get(0).getPercentage());

        assertEquals("Transport", summary.getCategoryExpenses().get(1).getCategory());
        assertEquals(0, new BigDecimal("1000.00").compareTo(summary.getCategoryExpenses().get(1).getAmount()));
        assertEquals(25.0, summary.getCategoryExpenses().get(1).getPercentage());

        // Recent transactions count <= 5
        assertEquals(4, summary.getRecentTransactions().size());
    }
}
