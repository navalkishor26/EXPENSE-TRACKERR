package com.expensetracker.service;

import com.expensetracker.dto.CategoryExpenseDTO;
import com.expensetracker.dto.DashboardSummaryResponse;
import com.expensetracker.dto.TransactionResponse;
import com.expensetracker.model.TransactionType;
import com.expensetracker.repository.TransactionRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class DashboardService {

    private final TransactionRepository transactionRepository;

    public DashboardService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    public DashboardSummaryResponse getDashboardSummary() {
        BigDecimal totalIncome = transactionRepository.sumAmountByType(TransactionType.INCOME);
        if (totalIncome == null) {
            totalIncome = BigDecimal.ZERO;
        }

        BigDecimal totalExpenses = transactionRepository.sumAmountByType(TransactionType.EXPENSE);
        if (totalExpenses == null) {
            totalExpenses = BigDecimal.ZERO;
        }

        BigDecimal availableBalance = totalIncome.subtract(totalExpenses);
        long totalTransactionCount = transactionRepository.count();

        List<Object[]> rawCategories = transactionRepository.sumAmountGroupedByCategory(TransactionType.EXPENSE);
        List<CategoryExpenseDTO> categoryExpenses = new ArrayList<>();

        for (Object[] row : rawCategories) {
            String category = (String) row[0];
            BigDecimal amount = (BigDecimal) row[1];
            double percentage = 0.0;
            if (totalExpenses.compareTo(BigDecimal.ZERO) > 0) {
                percentage = amount.divide(totalExpenses, 4, RoundingMode.HALF_UP)
                        .multiply(BigDecimal.valueOf(100))
                        .setScale(2, RoundingMode.HALF_UP)
                        .doubleValue();
            }
            categoryExpenses.add(new CategoryExpenseDTO(category, amount, percentage));
        }

        List<TransactionResponse> recentTransactions = transactionRepository.findRecentTransactions(PageRequest.of(0, 5))
                .stream()
                .map(TransactionResponse::fromEntity)
                .collect(Collectors.toList());

        return new DashboardSummaryResponse(
                totalIncome,
                totalExpenses,
                availableBalance,
                totalTransactionCount,
                categoryExpenses,
                recentTransactions
        );
    }
}
