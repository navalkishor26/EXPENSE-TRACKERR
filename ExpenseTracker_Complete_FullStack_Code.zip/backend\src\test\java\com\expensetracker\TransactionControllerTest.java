package com.expensetracker;

import com.expensetracker.dto.TransactionRequest;
import com.expensetracker.model.TransactionType;
import com.expensetracker.repository.TransactionRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
public class TransactionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        transactionRepository.deleteAll();
    }

    @Test
    void testCreateTransaction_Success() throws Exception {
        TransactionRequest request = new TransactionRequest(
                TransactionType.EXPENSE,
                new BigDecimal("250.50"),
                "Food",
                "Lunch with friends",
                LocalDate.of(2026, 10, 27)
        );

        mockMvc.perform(post("/api/transactions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id", notNullValue()))
                .andExpect(jsonPath("$.type", is("EXPENSE")))
                .andExpect(jsonPath("$.amount", is(250.50)))
                .andExpect(jsonPath("$.category", is("Food")))
                .andExpect(jsonPath("$.description", is("Lunch with friends")));
    }

    @Test
    void testCreateTransaction_InvalidAmount_ZeroOrNegative() throws Exception {
        TransactionRequest zeroRequest = new TransactionRequest(
                TransactionType.EXPENSE,
                BigDecimal.ZERO,
                "Food",
                "Zero amount",
                LocalDate.of(2026, 10, 27)
        );

        mockMvc.perform(post("/api/transactions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(zeroRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status", is(400)))
                .andExpect(jsonPath("$.details.amount", notNullValue()));

        TransactionRequest negativeRequest = new TransactionRequest(
                TransactionType.EXPENSE,
                new BigDecimal("-50.00"),
                "Transport",
                "Negative amount",
                LocalDate.of(2026, 10, 27)
        );

        mockMvc.perform(post("/api/transactions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(negativeRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.details.amount", notNullValue()));
    }

    @Test
    void testCreateTransaction_MissingRequiredFields() throws Exception {
        TransactionRequest emptyRequest = new TransactionRequest();

        mockMvc.perform(post("/api/transactions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(emptyRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.details.type", notNullValue()))
                .andExpect(jsonPath("$.details.amount", notNullValue()))
                .andExpect(jsonPath("$.details.category", notNullValue()))
                .andExpect(jsonPath("$.details.transactionDate", notNullValue()));
    }

    @Test
    void testGetNonExistentTransaction_Returns404() throws Exception {
        mockMvc.perform(get("/api/transactions/99999"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status", is(404)))
                .andExpect(jsonPath("$.error", is("Not Found")));
    }

    @Test
    void testUpdateTransaction_Success() throws Exception {
        TransactionRequest createReq = new TransactionRequest(
                TransactionType.INCOME,
                new BigDecimal("50000.00"),
                "Salary",
                "Monthly Salary",
                LocalDate.of(2026, 10, 1)
        );

        String response = mockMvc.perform(post("/api/transactions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(createReq)))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();

        Long id = objectMapper.readTree(response).get("id").asLong();

        TransactionRequest updateReq = new TransactionRequest(
                TransactionType.INCOME,
                new BigDecimal("55000.00"),
                "Salary",
                "Updated Monthly Salary with Bonus",
                LocalDate.of(2026, 10, 1)
        );

        mockMvc.perform(put("/api/transactions/" + id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateReq)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(id.intValue())))
                .andExpect(jsonPath("$.amount", is(55000.00)))
                .andExpect(jsonPath("$.description", is("Updated Monthly Salary with Bonus")));
    }

    @Test
    void testDeleteTransaction_Success() throws Exception {
        TransactionRequest createReq = new TransactionRequest(
                TransactionType.EXPENSE,
                new BigDecimal("120.00"),
                "Transport",
                "Bus ticket",
                LocalDate.of(2026, 10, 26)
        );

        String response = mockMvc.perform(post("/api/transactions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(createReq)))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();

        Long id = objectMapper.readTree(response).get("id").asLong();

        mockMvc.perform(delete("/api/transactions/" + id))
                .andExpect(status().isNoContent());

        mockMvc.perform(get("/api/transactions/" + id))
                .andExpect(status().isNotFound());
    }

    @Test
    void testFilterTransactionsByTypeAndCategory() throws Exception {
        mockMvc.perform(post("/api/transactions")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(new TransactionRequest(
                        TransactionType.EXPENSE, new BigDecimal("100"), "Food", "Snack", LocalDate.of(2026, 10, 20)))));

        mockMvc.perform(post("/api/transactions")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(new TransactionRequest(
                        TransactionType.EXPENSE, new BigDecimal("200"), "Transport", "Cab", LocalDate.of(2026, 10, 21)))));

        mockMvc.perform(post("/api/transactions")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(new TransactionRequest(
                        TransactionType.INCOME, new BigDecimal("30000"), "Salary", "Oct Pay", LocalDate.of(2026, 10, 1)))));

        // Filter by EXPENSE
        mockMvc.perform(get("/api/transactions?type=EXPENSE"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)));

        // Filter by category Food
        mockMvc.perform(get("/api/transactions?category=Food"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].category", is("Food")));
    }
}
