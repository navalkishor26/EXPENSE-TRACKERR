import React from 'react';
import { Menu, Wallet } from 'lucide-react';
import { TabType } from './Sidebar';

interface NavbarProps {
  activeTab: TabType;
  onOpenSidebar: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, onOpenSidebar }) => {
  const titles: Record<TabType, { title: string; subtitle: string }> = {
    dashboard: {
      title: 'Dashboard Overview',
      subtitle: 'Monitor your financial health and recent movements',
    },
    add: {
      title: 'Record Transaction',
      subtitle: 'Add a new income source or expense entry',
    },
    history: {
      title: 'Transaction History',
      subtitle: 'View, filter, edit, and manage all your past records',
    },
    monthly: {
      title: 'Monthly Summary & Analytics',
      subtitle: 'Review monthly balance, comparisons, and top expenditures',
    },
    chat: {
      title: 'Financial Assistant',
      subtitle: 'Ask questions about your finances in plain English',
    },
  };

  const current = titles[activeTab];

  return (
    <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-8 py-4 flex items-center justify-between">
      <div className="flex items-center space-x-3">
        <button
          onClick={onOpenSidebar}
          className="p-2 -ml-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 lg:hidden"
          aria-label="Open sidebar"
        >
          <Menu className="w-6 h-6" />
        </button>

        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            {current.title}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 hidden sm:block">
            {current.subtitle}
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-2">
        <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-full text-xs font-semibold text-slate-700">
          <Wallet className="w-3.5 h-3.5 text-blue-600" />
          <span>₹ INR</span>
        </div>
      </div>
    </header>
  );
};
