package com.expensetracker.repository;

import com.expensetracker.model.Transaction;
import com.expensetracker.model.TransactionType;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    List<Transaction> findAllByOrderByTransactionDateDescIdDesc();

    List<Transaction> findByTypeOrderByTransactionDateDescIdDesc(TransactionType type);

    List<Transaction> findByCategoryIgnoreCaseOrderByTransactionDateDescIdDesc(String category);

    List<Transaction> findByTypeAndCategoryIgnoreCaseOrderByTransactionDateDescIdDesc(TransactionType type, String category);

    @Query("SELECT t FROM Transaction t ORDER BY t.transactionDate DESC, t.id DESC")
    List<Transaction> findRecentTransactions(Pageable pageable);

    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t WHERE t.type = :type")
    BigDecimal sumAmountByType(@Param("type") TransactionType type);

    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t WHERE t.type = :type AND t.transactionDate BETWEEN :startDate AND :endDate")
    BigDecimal sumAmountByTypeAndDateRange(@Param("type") TransactionType type,
                                           @Param("startDate") LocalDate startDate,
                                           @Param("endDate") LocalDate endDate);

    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t WHERE t.type = :type AND LOWER(t.category) = LOWER(:category)")
    BigDecimal sumAmountByTypeAndCategory(@Param("type") TransactionType type,
                                          @Param("category") String category);

    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t WHERE t.type = :type AND LOWER(t.category) = LOWER(:category) AND t.transactionDate BETWEEN :startDate AND :endDate")
    BigDecimal sumAmountByTypeAndCategoryAndDateRange(@Param("type") TransactionType type,
                                                      @Param("category") String category,
                                                      @Param("startDate") LocalDate startDate,
                                                      @Param("endDate") LocalDate endDate);

    @Query("SELECT t.category AS category, SUM(t.amount) AS total FROM Transaction t WHERE t.type = :type GROUP BY t.category ORDER BY SUM(t.amount) DESC")
    List<Object[]> sumAmountGroupedByCategory(@Param("type") TransactionType type);

    @Query("SELECT t.category AS category, SUM(t.amount) AS total FROM Transaction t WHERE t.type = :type AND t.transactionDate BETWEEN :startDate AND :endDate GROUP BY t.category ORDER BY SUM(t.amount) DESC")
    List<Object[]> sumAmountGroupedByCategoryAndDateRange(@Param("type") TransactionType type,
                                                         @Param("startDate") LocalDate startDate,
                                                         @Param("endDate") LocalDate endDate);
}
