package com.expensetracker;

import com.expensetracker.dto.ChatRequest;
import com.expensetracker.dto.ChatResponse;
import com.expensetracker.model.Transaction;
import com.expensetracker.model.TransactionType;
import com.expensetracker.repository.TransactionRepository;
import com.expensetracker.service.ChatAssistantService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
public class ChatAssistantServiceTest {

    @Autowired
    private ChatAssistantService chatAssistantService;

    @Autowired
    private TransactionRepository transactionRepository;

    @BeforeEach
    void setUp() {
        transactionRepository.deleteAll();

        LocalDate today = LocalDate.now();

        // Income: 75,000 this month
        transactionRepository.save(new Transaction(
                TransactionType.INCOME, new BigDecimal("75000.00"), "Salary", "October Pay", today));

        // Expenses this month
        transactionRepository.save(new Transaction(
                TransactionType.EXPENSE, new BigDecimal("4500.00"), "Food", "Restaurants", today));
        transactionRepository.save(new Transaction(
                TransactionType.EXPENSE, new BigDecimal("1500.00"), "Transport", "Cab", today));
        transactionRepository.save(new Transaction(
                TransactionType.EXPENSE, new BigDecimal("6000.00"), "Entertainment", "Concert", today));
    }

    @Test
    void testQuestion_SpendThisMonth() {
        ChatResponse res = chatAssistantService.processMessage(new ChatRequest("How much did I spend this month?"));
        assertEquals("MONTHLY_EXPENSES", res.getIntent());
        // 4500 + 1500 + 6000 = 12000
        assertTrue(res.getReply().contains("12,000.00"), "Reply should contain 12,000.00: " + res.getReply());
    }

    @Test
    void testQuestion_CurrentBalance() {
        ChatResponse res = chatAssistantService.processMessage(new ChatRequest("What is my current balance?"));
        assertEquals("CURRENT_BALANCE", res.getIntent());
        // 75000 - 12000 = 63000
        assertTrue(res.getReply().contains("63,000.00"), "Reply should contain 63,000.00: " + res.getReply());
    }

    @Test
    void testQuestion_IncomeThisMonth() {
        ChatResponse res = chatAssistantService.processMessage(new ChatRequest("How much income did I receive this month?"));
        assertEquals("MONTHLY_INCOME", res.getIntent());
        assertTrue(res.getReply().contains("75,000.00"), "Reply should contain 75,000.00: " + res.getReply());
    }

    @Test
    void testQuestion_HighestSpendingCategory() {
        ChatResponse res = chatAssistantService.processMessage(new ChatRequest("Which category did I spend the most on?"));
        assertEquals("HIGHEST_CATEGORY", res.getIntent());
        assertTrue(res.getReply().contains("Entertainment"), "Reply should indicate Entertainment: " + res.getReply());
        assertTrue(res.getReply().contains("6,000.00"), "Reply should contain 6,000.00: " + res.getReply());
    }

    @Test
    void testQuestion_SpendOnFood() {
        ChatResponse res = chatAssistantService.processMessage(new ChatRequest("How much did I spend on food?"));
        assertEquals("CATEGORY_EXPENSE", res.getIntent());
        assertTrue(res.getReply().contains("Food"), "Reply should mention Food: " + res.getReply());
        assertTrue(res.getReply().contains("4,500.00"), "Reply should contain 4,500.00: " + res.getReply());
    }

    @Test
    void testQuestion_TotalExpenses() {
        ChatResponse res = chatAssistantService.processMessage(new ChatRequest("What are my total expenses?"));
        assertEquals("TOTAL_EXPENSES", res.getIntent());
        assertTrue(res.getReply().contains("12,000.00"), "Reply should contain 12,000.00: " + res.getReply());
    }

    @Test
    void testQuestion_TotalTransactions() {
        ChatResponse res = chatAssistantService.processMessage(new ChatRequest("How many transactions do I have?"));
        assertEquals("TRANSACTION_COUNT", res.getIntent());
        assertTrue(res.getReply().contains("4 transactions"), "Reply should state 4 transactions: " + res.getReply());
    }

    @Test
    void testQuestion_UnsupportedFallback() {
        ChatResponse res = chatAssistantService.processMessage(new ChatRequest("Will it rain tomorrow?"));
        assertEquals("UNSUPPORTED", res.getIntent());
        assertTrue(res.getReply().contains("I can help you answer questions"), "Reply should explain supported queries");
    }
}
