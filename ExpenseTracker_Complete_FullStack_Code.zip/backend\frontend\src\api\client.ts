import axios from 'axios';
import {
  DashboardSummary,
  MonthlyReport,
  Transaction,
  TransactionRequest,
  TransactionType,
} from '../types';

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api';

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const api = {
  // Health
  checkHealth: async () => {
    const res = await apiClient.get('/health');
    return res.data;
  },

  // Dashboard
  getDashboardSummary: async (): Promise<DashboardSummary> => {
    const res = await apiClient.get<DashboardSummary>('/dashboard/summary');
    return res.data;
  },

  // Transactions
  getTransactions: async (type?: TransactionType, category?: string): Promise<Transaction[]> => {
    const params: Record<string, string> = {};
    if (type) params.type = type;
    if (category && category !== 'ALL') params.category = category;
    const res = await apiClient.get<Transaction[]>('/transactions', { params });
    return res.data;
  },

  getTransactionById: async (id: number): Promise<Transaction> => {
    const res = await apiClient.get<Transaction>(`/transactions/${id}`);
    return res.data;
  },

  createTransaction: async (data: TransactionRequest): Promise<Transaction> => {
    const res = await apiClient.post<Transaction>('/transactions', data);
    return res.data;
  },

  updateTransaction: async (id: number, data: TransactionRequest): Promise<Transaction> => {
    const res = await apiClient.put<Transaction>(`/transactions/${id}`, data);
    return res.data;
  },

  deleteTransaction: async (id: number): Promise<void> => {
    await apiClient.delete(`/transactions/${id}`);
  },

  // Monthly Report
  getMonthlyReport: async (month: number, year: number): Promise<MonthlyReport> => {
    const res = await apiClient.get<MonthlyReport>('/reports/monthly', {
      params: { month, year },
    });
    return res.data;
  },

  // Chat Assistant
  sendChatMessage: async (message: string): Promise<{ reply: string; intent: string }> => {
    const res = await apiClient.post<{ reply: string; intent: string }>('/assistant/chat', {
      message,
    });
    return res.data;
  },
};
