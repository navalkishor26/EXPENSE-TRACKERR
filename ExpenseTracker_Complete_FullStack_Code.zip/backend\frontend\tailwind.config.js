/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          sidebar: "#0f172a", // Dark blue slate
          sidebarHover: "#1e293b",
          sidebarActive: "#2563eb",
          income: "#059669",  // Emerald green
          incomeBg: "#ecfdf5",
          expense: "#e11d48", // Rose red
          expenseBg: "#fff1f2",
        }
      }
    },
  },
  plugins: [],
}
