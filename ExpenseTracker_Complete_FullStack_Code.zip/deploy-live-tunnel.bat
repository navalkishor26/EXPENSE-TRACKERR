@echo off
setlocal enabledelayedexpansion
title Expense Tracker - Live Public Tunnel
echo ========================================================
echo     Expense Tracker - Instant Live Public Deployment
echo ========================================================
echo.

set "ROOT_DIR=%~dp0"
set "CLOUDFLARED=%ROOT_DIR%tools\bin\cloudflared.exe"

:: 1. Check if backend & frontend are running
echo [1/3] Checking if local servers are active...
netstat -ano | findstr ":5173" >nul
if %errorlevel% neq 0 (
    echo Local servers are not running yet.
    echo Launching Backend (Port 8080) and Frontend (Port 5173)...
    start "Expense Tracker - Local Server" "%ROOT_DIR%start-expense-tracker.bat"
    echo Waiting 8 seconds for servers to initialize...
    ping -n 9 127.0.0.1 >nul
) else (
    echo Local server is active on http://localhost:5173!
)

:: 2. Ensure Cloudflare Tunnel binary exists
echo.
echo [2/3] Checking Cloudflare Tunnel utility...
if not exist "%CLOUDFLARED%" (
    echo Downloading portable Cloudflare Tunnel binary (one-time setup)...
    curl.exe -L "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe" -o "%CLOUDFLARED%"
    if not exist "%CLOUDFLARED%" (
        echo [!] Could not download cloudflared. Falling back to localtunnel via npx...
        goto fallback_localtunnel
    )
    echo Download completed successfully!
) else (
    echo Cloudflare Tunnel binary is ready.
)

:: 3. Launch Cloudflare Tunnel
echo.
echo [3/3] Exposing http://localhost:5173 to the public internet...
echo ========================================================
echo  SUCCESS! Your public URL will appear below in 2-3 seconds:
echo  (Look for the link ending in .trycloudflare.com)
echo.
echo  Example: https://xxxx-xxxx.trycloudflare.com
echo.
echo  * You can open this link on your phone or share it with anyone!
echo  * Keep this window open while you want the link active.
echo ========================================================
echo.

"%CLOUDFLARED%" tunnel --url http://localhost:5173
goto end

:fallback_localtunnel
echo.
echo ========================================================
echo Starting tunnel using npx localtunnel...
echo ========================================================
set "PATH=%ROOT_DIR%tools\node-v20.18.0-win-x64;%PATH%"
npx --yes localtunnel --port 5173

:end
pause
