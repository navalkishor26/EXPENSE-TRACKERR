@echo off
title Expense Tracker - Local Host Server
echo ========================================================
echo       Starting Expense Tracker Full-Stack Application
echo ========================================================
echo.

set "ROOT_DIR=%~dp0"
set "JAVA_HOME=%ROOT_DIR%tools\jdk-21"
set "PATH=%ROOT_DIR%tools\jdk-21\bin;%ROOT_DIR%tools\bin;%ROOT_DIR%tools\node-v20.18.0-win-x64;%PATH%"

echo [1/2] Starting Spring Boot Backend (Port 8080)...
start "Expense Tracker - Backend (Port 8080)" /d "%ROOT_DIR%backend" cmd /k "title Backend (Port 8080) & set JAVA_HOME=%JAVA_HOME%& set PATH=%PATH%& mvn spring-boot:run "-Dspring-boot.run.profiles=h2""

echo [2/2] Starting React Vite Frontend (Port 5173)...
start "Expense Tracker - Frontend (Port 5173)" /d "%ROOT_DIR%backend\frontend" cmd /k "title Frontend (Port 5173) & set PATH=%PATH%& npm run dev -- --host"

echo.
echo ========================================================
echo   Backend is starting at : http://localhost:8080
echo   Frontend is starting at: http://localhost:5173
echo ========================================================
echo.
echo Once started, open your browser at:
echo    http://localhost:5173
echo.
ping -n 6 127.0.0.1 >nul
start http://localhost:5173
